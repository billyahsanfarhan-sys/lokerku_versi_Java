package com.example.lokerku;

import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;

/** Shared, short-lived UI motion. No listener consumes a click. */
public final class UiMotion {
    private UiMotion() { }

    private static float dp(View view, float value) {
        return value * view.getResources().getDisplayMetrics().density;
    }

    public static void reveal(View view, long delay) {
        if (view == null || view.getVisibility() != View.VISIBLE) return;
        view.animate().cancel();
        view.setTranslationY(dp(view, 14));
        // Buttons can have their alpha changed by request/loading state.
        if (!(view instanceof Button)) view.setAlpha(0.78f);
        view.setTag(R.id.ui_motion_revealing, Boolean.TRUE);
        android.view.ViewPropertyAnimator animation = view.animate().translationY(0f);
        if (!(view instanceof Button)) animation.alpha(1f);
        animation.setStartDelay(delay).setDuration(560)
                .setInterpolator(new DecelerateInterpolator(1.4f))
                .withEndAction(() -> view.setTag(R.id.ui_motion_revealing, null)).start();
    }

    public static void revealChildren(ViewGroup group, long start, long step, int max) {
        int n = 0;
        for (int i = 0; i < group.getChildCount() && n < max; i++) {
            View child = group.getChildAt(i);
            if (child.getVisibility() != View.VISIBLE) continue;
            reveal(child, start + n * step);
            n++;
        }
    }

    public static void bindPress(View view) {
        if (Boolean.TRUE.equals(view.getTag(R.id.ui_motion_bound))) return;
        view.setTag(R.id.ui_motion_bound, Boolean.TRUE);
        view.setOnTouchListener((v, event) -> {
            if (!v.isEnabled() || Boolean.TRUE.equals(v.getTag(R.id.ui_motion_revealing))) return false;
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    v.animate().scaleX(.97f).scaleY(.97f).setStartDelay(0)
                            .setDuration(140).setInterpolator(new DecelerateInterpolator()).start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.animate().scaleX(1f).scaleY(1f).setStartDelay(0)
                            .setDuration(240).setInterpolator(new DecelerateInterpolator()).start();
                    break;
                default: break;
            }
            return false;
        });
    }

    public static void styleButtons(View view) {
        if (view instanceof Button && !Boolean.TRUE.equals(view.getTag(R.id.ui_motion_bound))) {
            Button button = (Button) view;
            button.setAllCaps(false);
            button.setMinHeight((int) dp(button, 48));
            Drawable bg = button.getBackground();
            if (bg != null) {
                roundButtonSurface(bg, dp(button, 16));
                button.setBackgroundTintList(null);
                button.setBackground(new RippleDrawable(ColorStateList.valueOf(0x330000FF), bg.mutate(), null));
            }
            bindPress(button);
        }
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) styleButtons(group.getChildAt(i));
        }
    }

    // Preserve each button's color and semantics while unifying its corner radius.
    private static void roundButtonSurface(Drawable drawable, float radius) {
        if (drawable instanceof android.graphics.drawable.GradientDrawable) {
            ((android.graphics.drawable.GradientDrawable) drawable).setCornerRadius(radius);
        } else if (drawable instanceof android.graphics.drawable.InsetDrawable) {
            Drawable child = ((android.graphics.drawable.InsetDrawable) drawable).getDrawable();
            if (child != null) roundButtonSurface(child, radius);
        } else if (drawable instanceof android.graphics.drawable.LayerDrawable) {
            android.graphics.drawable.LayerDrawable layers = (android.graphics.drawable.LayerDrawable) drawable;
            for (int i=0;i<layers.getNumberOfLayers();i++) {
                Drawable child=layers.getDrawable(i);
                if (child!=null) roundButtonSurface(child,radius);
            }
        }
    }

    public static void bindActions(View view) {
        if (view.isClickable() && !(view instanceof android.widget.EditText)
                && !Boolean.TRUE.equals(view.getTag(R.id.ui_motion_skip_press))) {
            bindPress(view);
        }
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) bindActions(group.getChildAt(i));
        }
    }

    public static void finishReveals(View view) {
        if (view == null) return;
        if (Boolean.TRUE.equals(view.getTag(R.id.ui_motion_revealing))) {
            view.animate().cancel();
            view.setTranslationY(0f);
            // Preserve a disabled button's loading opacity.
            if (!(view instanceof Button)) view.setAlpha(1f);
            view.setTag(R.id.ui_motion_revealing, null);
        }
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) finishReveals(group.getChildAt(i));
        }
    }
}
