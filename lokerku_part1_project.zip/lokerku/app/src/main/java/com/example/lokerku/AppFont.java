package com.example.lokerku;

import android.content.Context;
import android.graphics.Typeface;
import androidx.core.content.res.ResourcesCompat;

public final class AppFont {

    private AppFont() {
    }

    public static Typeface regular(Context context) {
        Typeface font = ResourcesCompat.getFont(
                context,
                R.font.poppins_regular
        );

        if (font == null) {
            throw new IllegalStateException(
                    "Font Poppins Regular tidak ditemukan"
            );
        }

        return font;
    }

    public static Typeface semibold(Context context) {
        Typeface font = ResourcesCompat.getFont(
                context,
                R.font.poppins_semibold
        );

        if (font == null) {
            throw new IllegalStateException(
                    "Font Poppins SemiBold tidak ditemukan"
            );
        }

        return font;
    }
}