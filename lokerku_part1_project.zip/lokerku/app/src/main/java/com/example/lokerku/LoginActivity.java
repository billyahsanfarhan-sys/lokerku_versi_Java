package com.example.lokerku;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {

    private static final String URL_LOGIN =
            "https://ahannaja.cu.ma/lokerku_api/auth/login.php";

    private static final String PREF_NAME = "lokerku_user";

    private final int NAVY = Color.rgb(21, 26, 61);
    private final int TEAL = Color.rgb(0, 0, 255);
    private final int BG = Color.rgb(247, 248, 255);
    private final int MUTED = Color.rgb(104, 112, 143);
    private final int WHITE = Color.WHITE;

    private EditText etIdentity;
    private EditText etPassword;
    private Button btnLogin;
    private ProgressBar progressBar;
    private TextView tvRegister;
    private TextView tvForgotPassword;

    private RequestQueue requestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(0xff142d83);
        getWindow().setNavigationBarColor(0xff2e47b5);
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            getWindow().getDecorView().setSystemUiVisibility(
                    0);
        }

        requestQueue = Volley.newRequestQueue(getApplicationContext());

        buildLoginScreen();
    }

    private void buildLoginScreen() {
        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setBackgroundColor(Color.TRANSPARENT);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(22), dp(24), dp(22), dp(26));

        scrollView.addView(root);

        TextView brand = new TextView(this);
        brand.setText("✦   LOKERKU"); brand.setTextColor(0xffe5efff); brand.setTextSize(13);
        brand.setLetterSpacing(.12f); brand.setTypeface(AppFont.semibold(this));
        brand.setGravity(Gravity.CENTER); brand.setPadding(0, dp(8), 0, dp(16));
        root.addView(brand, matchWrap());
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(24), dp(28), dp(24), dp(26));
        GradientDrawable cardBackground = AuthGlass.card(this);
        card.setBackground(cardBackground);
        card.setElevation(dp(3));

        root.addView(card, matchWrap());

        TextView title = new TextView(this);
        title.setText("Selamat datang kembali");
        title.setTextColor(WHITE);
        title.setTextSize(25);
        title.setTypeface(AppFont.semibold(this));
        card.addView(title, matchWrap());

        TextView description = new TextView(this);
        description.setText("Masuk ke akunmu untuk menemukan pekerjaan.");
        description.setTextColor(0xffe2ebff);
        description.setTextSize(14);

        LinearLayout.LayoutParams descParams = matchWrap();
        descParams.topMargin = dp(8);
        descParams.bottomMargin = dp(25);
        card.addView(description, descParams);

        addLabel(card, "Email atau Username");

        etIdentity = createEditText(
                "Masukkan email atau username",
                false
        );

        card.addView(etIdentity, matchWrap());

        LinearLayout.LayoutParams passwordLabelParams = matchWrap();
        passwordLabelParams.topMargin = dp(20);
        card.addView(createLabel("Password"), passwordLabelParams);

        etPassword = createEditText("Masukkan password", true);
        card.addView(etPassword, matchWrap());

        tvForgotPassword = new TextView(this);
        tvForgotPassword.setText("Lupa password?");
        tvForgotPassword.setTextColor(0xffe2efff);
        tvForgotPassword.setTextSize(14);
        tvForgotPassword.setGravity(Gravity.END);
        tvForgotPassword.setPadding(0, dp(14), 0, dp(14));

        LinearLayout.LayoutParams forgotParams = matchWrap();
        forgotParams.topMargin = dp(2);
        card.addView(tvForgotPassword, forgotParams);

        tvForgotPassword.setOnClickListener(v -> {
            startActivity(new Intent(
                    LoginActivity.this,
                    ForgotPasswordActivity.class
            ));
        });

        btnLogin = new Button(this);
        btnLogin.setText("Masuk");
        btnLogin.setTextColor(WHITE);
        btnLogin.setTextSize(16);
        btnLogin.setAllCaps(false);
        btnLogin.setTypeface(AppFont.semibold(this));
        GradientDrawable loginButton = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(0, 0, 204), TEAL});
        loginButton.setCornerRadius(dp(18));
        btnLogin.setBackgroundTintList(null);
        btnLogin.setStateListAnimator(null);
        btnLogin.setBackground(loginButton);
        btnLogin.setMinHeight(dp(54));
        btnLogin.setElevation(dp(2));

        LinearLayout.LayoutParams buttonParams = matchWrap();
        buttonParams.topMargin = dp(8);
        card.addView(btnLogin, buttonParams);
        TextView separator = new TextView(this); separator.setText("ATAU LANJUTKAN DENGAN");
        separator.setTextColor(0xffd7e5ff); separator.setTextSize(10); separator.setLetterSpacing(.08f);
        separator.setGravity(Gravity.CENTER); separator.setPadding(0, dp(16), 0, 0); card.addView(separator);
        GoogleDesign.addTo(card, this, "Masuk dengan Google");

        progressBar = new ProgressBar(this);
        progressBar.setIndeterminate(true);
        progressBar.setVisibility(View.GONE);

        LinearLayout.LayoutParams progressParams = new LinearLayout.LayoutParams(
                dp(36),
                dp(36)
        );
        progressParams.gravity = Gravity.CENTER;
        progressParams.topMargin = dp(16);
        card.addView(progressBar, progressParams);

        LinearLayout registerRow = new LinearLayout(this);
        registerRow.setGravity(Gravity.CENTER);
        registerRow.setOrientation(LinearLayout.HORIZONTAL);

        LinearLayout.LayoutParams registerParams = matchWrap();
        registerParams.topMargin = dp(24);
        card.addView(registerRow, registerParams);

        TextView registerText = new TextView(this);
        registerText.setText("Belum punya akun? ");
        registerText.setTextColor(0xffe2ebff);
        registerText.setTextSize(14);
        registerRow.addView(registerText);

        tvRegister = new TextView(this);
        tvRegister.setText("Daftar");
        tvRegister.setTextColor(WHITE);
        tvRegister.setTextSize(14);
        tvRegister.setPadding(dp(8), dp(12), dp(8), dp(12));
        tvRegister.setTypeface(AppFont.semibold(this));
        registerRow.addView(tvRegister);

        tvRegister.setOnClickListener(v -> {
            startActivity(new Intent(
                    LoginActivity.this,
                    RegisterActivity.class
            ));
        });

        btnLogin.setOnClickListener(v -> loginUser());

        android.widget.FrameLayout scene = new android.widget.FrameLayout(this);
        scene.addView(new AuthAmbientView(this), new android.widget.FrameLayout.LayoutParams(-1, -1));
        scene.addView(scrollView, new android.widget.FrameLayout.LayoutParams(-1, -1));
        setContentView(scene);
        FontEnforcer.apply(scrollView, this);
        UiMotion.styleButtons(scrollView);
        UiMotion.bindActions(scrollView);
        UiMotion.bindPress(tvRegister);
        UiMotion.bindPress(tvForgotPassword);
        UiMotion.reveal(card, 180);
        UiMotion.revealChildren(card, 260, 55, 12);
    }

    @Override protected void onPause() {
        UiMotion.finishReveals(getWindow().getDecorView());
        super.onPause();
    }

    private void addLabel(LinearLayout parent, String text) {
        parent.addView(createLabel(text), matchWrap());
    }

    private TextView createLabel(String text) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextColor(WHITE);
        label.setTextSize(14);
        label.setTypeface(AppFont.semibold(this));
        return label;
    }

    private EditText createEditText(String hint, boolean password) {
        EditText editText = new EditText(this);
        editText.setSingleLine(true);
        editText.setTextColor(WHITE);
        editText.setHintTextColor(0xffc8d7f5);
        editText.setTextSize(14);
        editText.setHint(hint);
        editText.setPadding(dp(15), dp(12), dp(15), dp(12));
        GradientDrawable inputBackground = AuthGlass.field(this, false);
        editText.setBackgroundTintList(null);
        editText.setBackground(inputBackground);
        editText.setOnFocusChangeListener((field, focused) -> {
            inputBackground.setStroke(dp(focused ? 2 : 1), focused ? 0xffd4eeff : 0x99c6dcff);
            android.animation.ObjectAnimator lift = android.animation.ObjectAnimator.ofFloat(
                    field, View.TRANSLATION_Z, focused ? dp(3) : 0f);
            lift.setDuration(220);
            lift.start();
        });
        editText.setMinHeight(dp(52));

        if (password) {
            editText.setInputType(
                    android.text.InputType.TYPE_CLASS_TEXT
                            | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            );
        } else {
            editText.setInputType(
                    android.text.InputType.TYPE_CLASS_TEXT
                            | android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
            );
        }

        // InputType may reset password fields to monospace; keep the project's Poppins font.
        editText.setTypeface(AppFont.regular(this));
        return editText;
    }

    private void loginUser() {
        String identity = etIdentity.getText().toString().trim();
        String password = etPassword.getText().toString();

        if (identity.isEmpty()) {
            etIdentity.setError("Email atau username wajib diisi");
            etIdentity.requestFocus();
            return;
        }

        if (password.isEmpty()) {
            etPassword.setError("Password wajib diisi");
            etPassword.requestFocus();
            return;
        }

        hideKeyboard();
        setLoading(true);

        StringRequest request = new StringRequest(
                Request.Method.POST,
                URL_LOGIN,
                responseText -> {
                    setLoading(false);

                    try {
                        JSONObject response = new JSONObject(responseText);
                        boolean success = response.optBoolean("success", false);

                        if (!success) {
                            String message = response.optString(
                                    "message",
                                    "Login gagal"
                            );

                            Toast.makeText(
                                    LoginActivity.this,
                                    message,
                                    Toast.LENGTH_LONG
                            ).show();
                            return;
                        }

                        JSONObject user = response.optJSONObject("user");

                        if (user == null) {
                            user = response.optJSONObject("data");
                        }

                        if (user == null) {
                            Toast.makeText(
                                    LoginActivity.this,
                                    "Data pengguna tidak ditemukan",
                                    Toast.LENGTH_LONG
                            ).show();
                            return;
                        }

                        int userId = user.optInt("id", 0);

                        if (userId <= 0) {
                            Toast.makeText(
                                    LoginActivity.this,
                                    "ID pengguna tidak valid",
                                    Toast.LENGTH_LONG
                            ).show();
                            return;
                        }

                        String username = user.isNull("username") ? "" : user.optString("username", "");
                        String sessionToken = response.optString("session_token", "");
                        GoogleSignInFlow.saveUser(LoginActivity.this, user, sessionToken);

                        Toast.makeText(
                                LoginActivity.this,
                                "Login berhasil",
                                Toast.LENGTH_SHORT
                        ).show();

                        Intent intent = new Intent(
                                LoginActivity.this,
                                MainActivity.class
                        );

                        intent.putExtra("username", username);
                        intent.setFlags(
                                Intent.FLAG_ACTIVITY_NEW_TASK
                                        | Intent.FLAG_ACTIVITY_CLEAR_TASK
                        );

                        startActivity(intent);

                    } catch (Exception e) {
                        Toast.makeText(
                                LoginActivity.this,
                                "Respons server tidak valid",
                                Toast.LENGTH_LONG
                        ).show();
                    }
                },
                error -> {
                    setLoading(false);

                    String message = "Tidak dapat terhubung ke server";

                    if (error.networkResponse != null && error.networkResponse.data != null) {
                        try {
                            JSONObject json = new JSONObject(new String(error.networkResponse.data, java.nio.charset.StandardCharsets.UTF_8));
                            message = json.optString("message", message);
                        } catch (Exception ignored) { }
                    }

                    Toast.makeText(
                            LoginActivity.this,
                            message,
                            Toast.LENGTH_LONG
                    ).show();
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("username", identity);
                params.put("password", password);
                return params;
            }
        };

        request.setShouldCache(false);
        request.setRetryPolicy(
                new com.android.volley.DefaultRetryPolicy(
                        15000,
                        1,
                        1.0f
                )
        );

        requestQueue.add(request);
    }

    private void setLoading(boolean loading) {
        btnLogin.setEnabled(!loading);
        btnLogin.setText(loading ? "Memproses..." : "Masuk");
        progressBar.setVisibility(
                loading ? View.VISIBLE : View.GONE
        );
    }

    private void hideKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager)
                    getSystemService(Context.INPUT_METHOD_SERVICE);

            if (imm != null && getCurrentFocus() != null) {
                imm.hideSoftInputFromWindow(
                        getCurrentFocus().getWindowToken(),
                        0
                );
            }
        } catch (Exception ignored) {
        }
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        drawable.setStroke(dp(1), Color.rgb(226, 233, 241));
        return drawable;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
    }

    private int dp(int value) {
        return (int) (
                value * getResources().getDisplayMetrics().density + 0.5f
        );
    }
}
