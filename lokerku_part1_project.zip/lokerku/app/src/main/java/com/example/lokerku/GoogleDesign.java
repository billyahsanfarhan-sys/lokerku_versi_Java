package com.example.lokerku;

import android.content.Context;
import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** Google sign-in button. */
final class GoogleDesign {
    private GoogleDesign() { }
    static void addTo(LinearLayout parent, Context context, String title) {
        float density = context.getResources().getDisplayMetrics().density;
        int height = Math.round(52 * density);
        LinearLayout group = new LinearLayout(context);
        group.setGravity(Gravity.CENTER);
        group.setOrientation(LinearLayout.HORIZONTAL);
        GradientDrawable outline = new GradientDrawable();
        outline.setColor(Color.WHITE);
        outline.setCornerRadius(18 * density);
        outline.setStroke(Math.round(density), 0xff747775);
        group.setBackground(outline);
        ImageView logo = new ImageView(context);
        logo.setImageResource(R.drawable.google_g_official);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        group.addView(logo, new LinearLayout.LayoutParams(Math.round(25*density),Math.round(25*density)));
        TextView label = new TextView(context);
        label.setText(title); label.setTextSize(14); label.setTextColor(0xff1f1f1f);
        label.setTypeface(AppFont.semibold(context));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.leftMargin = Math.round(12*density); group.addView(label, lp);
        group.setContentDescription(title);
        group.setOnClickListener(v -> {
            if (!group.isEnabled()) return;
            group.setEnabled(false);
            label.setText("Menghubungkan ke Google…");
            GoogleSignInFlow.signIn((Activity) context, context instanceof RegisterActivity, () -> {
                group.setEnabled(true);
                label.setText(title);
            });
        });
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, height);
        params.topMargin = Math.round(16 * density); parent.addView(group, params);
    }
}
