package com.example.lokerku;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class CVBuilderActivity extends AppCompatActivity {
    private final int BLUE = Color.rgb(0, 82, 255);
    private final int DARK_BLUE = Color.rgb(18, 35, 88);
    private final int BG = Color.rgb(246, 248, 255);
    private final int TEXT = Color.rgb(28, 39, 66);
    private final int MUTED = Color.rgb(105, 117, 148);
    private final int BORDER = Color.rgb(222, 229, 245);
    private final int WHITE = Color.WHITE;

    private EditText name, email, phone, address, objective, education, experience, skills;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        if (android.os.Build.VERSION.SDK_INT >= 23) getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(14), dp(20), dp(28));
        scroll.addView(root);
        setContentView(scroll);
        FontEnforcer.apply(root, this);

        TextView back = text("‹   Kembali ke Beranda", 14, BLUE, true);
        back.setPadding(0, dp(8), 0, dp(20));
        back.setOnClickListener(v -> finish());
        back.setMinHeight(dp(48));
        root.addView(back);

        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(20), dp(22), dp(20), dp(22));
        hero.setBackground(gradient(BLUE, Color.rgb(82, 112, 255), 24));
        TextView tag = text("✦  CAREER TOOLKIT", 11, Color.WHITE, true);
        hero.addView(tag);
        TextView title = text("Buat CV profesionalmu", 25, Color.WHITE, true);
        LinearLayout.LayoutParams titleP = new LinearLayout.LayoutParams(-1, -2); titleP.topMargin = dp(10); hero.addView(title, titleP);
        TextView sub = text("Isi informasi penting di bawah. Susun pengalamanmu dengan jelas dan tampilkan kelebihan yang relevan.", 13, Color.rgb(238,242,255), false);
        sub.setLineSpacing(dp(3), 1f);
        LinearLayout.LayoutParams subP = new LinearLayout.LayoutParams(-1, -2); subP.topMargin = dp(8); hero.addView(sub, subP);
        root.addView(hero);

        LinearLayout progress = card();
        progress.setOrientation(LinearLayout.HORIZONTAL); progress.setGravity(Gravity.CENTER_VERTICAL);
        TextView circle = text("1", 14, Color.WHITE, true); circle.setGravity(Gravity.CENTER); circle.setBackground(gradient(BLUE, BLUE, 50));
        progress.addView(circle, new LinearLayout.LayoutParams(dp(34), dp(34)));
        LinearLayout progressText = new LinearLayout(this); progressText.setOrientation(LinearLayout.VERTICAL); progressText.setPadding(dp(12),0,0,0);
        progressText.addView(text("Lengkapi data CV", 14, TEXT, true));
        progressText.addView(text("Bagian bertanda wajib sebaiknya diisi", 11, MUTED, false));
        progress.addView(progressText, new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams progressP = new LinearLayout.LayoutParams(-1,-2); progressP.topMargin=dp(16); root.addView(progress,progressP);

        LinearLayout personal = section(root, "Informasi pribadi", "Gunakan data yang bisa dihubungi perekrut.");
        name = field(personal, "Nama lengkap *", "Contoh: Andi Pratama");
        email = field(personal, "Email *", "nama@email.com"); email.setInputType( android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS );
        phone = field(personal, "Nomor telepon", "Contoh: 081234567890"); phone.setInputType(android.text.InputType.TYPE_CLASS_PHONE);
        address = field(personal, "Domisili", "Kota tempat tinggal");

        LinearLayout objectiveCard = section(root, "Profil singkat", "Tulis 2–3 kalimat tentang kemampuan dan tujuan kariermu.");
        objective = multiField(objectiveCard, "Tentang saya", "Contoh: Lulusan Sistem Informasi yang tertarik pada pengembangan aplikasi dan analisis data...");

        LinearLayout educationCard = section(root, "Pendidikan", "Mulai dari pendidikan terbaru.");
        education = multiField(educationCard, "Riwayat pendidikan", "Nama sekolah/kampus, jurusan, tahun lulus");

        LinearLayout experienceCard = section(root, "Pengalaman", "Bisa berupa pekerjaan, magang, organisasi, atau proyek.");
        experience = multiField(experienceCard, "Pengalaman kerja / proyek", "Posisi atau proyek — tempat — periode\nTuliskan tanggung jawab dan hasil yang relevan.");

        LinearLayout skillsCard = section(root, "Keahlian", "Pisahkan setiap keahlian dengan koma.");
        skills = multiField(skillsCard, "Keahlian utama", "Contoh: Microsoft Excel, Java, komunikasi, kerja tim");

        LinearLayout tips = card(); tips.setOrientation(LinearLayout.VERTICAL); tips.setBackground(gradient(Color.rgb(235,243,255), Color.rgb(246,248,255), 18));
        tips.addView(text("✧  Tips CV yang lebih kuat", 14, DARK_BLUE, true));
        TextView tipsText = text("• Sesuaikan CV dengan posisi yang dilamar.\n• Utamakan informasi yang relevan dan mudah dibaca.\n• Periksa ejaan, tanggal, dan kontak sebelum dibagikan.", 12, MUTED, false);
        tipsText.setLineSpacing(dp(4),1f); LinearLayout.LayoutParams tipsTP=new LinearLayout.LayoutParams(-1,-2); tipsTP.topMargin=dp(8); tips.addView(tipsText,tipsTP);
        LinearLayout.LayoutParams tipsP=new LinearLayout.LayoutParams(-1,-2); tipsP.topMargin=dp(18); root.addView(tips,tipsP);

        Button preview = button("Pratinjau CV  →", BLUE);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(54)); bp.topMargin=dp(18); root.addView(preview,bp);
        preview.setOnClickListener(v -> showPreview());
        TextView footer = text("Pratinjau ini membantu merapikan isi CV. Pastikan semua informasi sudah benar sebelum kamu menyalinnya ke dokumen akhir.", 11, MUTED, false);
        footer.setGravity(Gravity.CENTER); footer.setLineSpacing(dp(3),1f); LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,-2); fp.topMargin=dp(12); root.addView(footer,fp);
        FontEnforcer.apply(root, this);
        UiMotion.styleButtons(scroll);
        UiMotion.bindActions(scroll);
        UiMotion.bindPress(back);
        UiMotion.revealChildren(root, 50, 70, 9);
    }

    @Override protected void onPause() {
        UiMotion.finishReveals(getWindow().getDecorView());
        super.onPause();
    }

    private LinearLayout section(LinearLayout root, String title, String subtitle) {
        TextView t=text(title,18,TEXT,true); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.topMargin=dp(23); root.addView(t,p);
        TextView s=text(subtitle,12,MUTED,false); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2); sp.topMargin=dp(5); sp.bottomMargin=dp(12); root.addView(s,sp);
        LinearLayout group = card();
        group.setPadding(dp(18), dp(18), dp(18), dp(8));
        root.addView(group, new LinearLayout.LayoutParams(-1, -2));
        return group;
    }
    private EditText field(LinearLayout root, String label, String hint) {
        root.addView(text(label,13,TEXT,true)); EditText e=new EditText(this); e.setTypeface(AppFont.regular(this)); e.setSingleLine(true); e.setTextSize(14); e.setTextColor(TEXT); e.setHintTextColor(MUTED); e.setHint(hint); e.setPadding(dp(14),0,dp(14),0); e.setBackground(outline());
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); e.setMinHeight(dp(52)); p.topMargin=dp(7); p.bottomMargin=dp(14); root.addView(e,p); return e;
    }
    private EditText multiField(LinearLayout root, String label, String hint) {
        root.addView(text(label,13,TEXT,true)); EditText e=new EditText(this); e.setTypeface(AppFont.regular(this)); e.setTextSize(14); e.setTextColor(TEXT); e.setHintTextColor(MUTED); e.setHint(hint); e.setGravity(Gravity.TOP|Gravity.START); e.setMinLines(3); e.setPadding(dp(14),dp(12),dp(14),dp(12)); e.setBackground(outline());
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); e.setMinHeight(dp(112)); p.topMargin=dp(7); p.bottomMargin=dp(14); root.addView(e,p); return e;
    }
    private void showPreview() {
        String n=value(name), em=value(email);
        if (TextUtils.isEmpty(n)) { name.setError("Nama lengkap wajib diisi"); name.requestFocus(); return; }
        if (TextUtils.isEmpty(em) || !android.util.Patterns.EMAIL_ADDRESS.matcher(em).matches()) { email.setError("Masukkan email yang valid"); email.requestFocus(); return; }
        try { ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(name.getWindowToken(),0); } catch(Exception ignored) {}
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(20),dp(18),dp(20),dp(18)); box.setBackground(rounded(WHITE,18));
        TextView heading=text(n.toUpperCase(),20,DARK_BLUE,true); box.addView(heading);
        TextView contact=text(join(value(email),value(phone),value(address)),11,MUTED,false); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2); cp.topMargin=dp(5); box.addView(contact,cp);
        addPreviewSection(box,"PROFIL",value(objective)); addPreviewSection(box,"PENDIDIKAN",value(education)); addPreviewSection(box,"PENGALAMAN",value(experience)); addPreviewSection(box,"KEAHLIAN",value(skills));
        ScrollView sc=new ScrollView(this); sc.addView(box);
        new PremiumDialog.Builder(this).setTitle("Pratinjau CV").setView(sc).setPositiveButton("Selesai",null).setNeutralButton("Bagikan isi",(d,w)->shareText(buildCvText())).show();
    }
    private void addPreviewSection(LinearLayout box,String title,String content) { if(TextUtils.isEmpty(content)) return; TextView h=text(title,12,BLUE,true); LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2); hp.topMargin=dp(16); box.addView(h,hp); TextView body=text(content,13,TEXT,false); body.setLineSpacing(dp(3),1f); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2); bp.topMargin=dp(5); box.addView(body,bp); }
    private String buildCvText() { return value(name)+"\n"+join(value(email),value(phone),value(address))+"\n\nPROFIL\n"+value(objective)+"\n\nPENDIDIKAN\n"+value(education)+"\n\nPENGALAMAN\n"+value(experience)+"\n\nKEAHLIAN\n"+value(skills); }
    private void shareText(String content) { android.content.Intent i=new android.content.Intent(android.content.Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(android.content.Intent.EXTRA_TEXT,content); startActivity(android.content.Intent.createChooser(i,"Bagikan CV")); }
    private String value(EditText e) { return e==null?"":e.getText().toString().trim(); }
    private String join(String... values) { StringBuilder b=new StringBuilder(); for(String v:values) if(!TextUtils.isEmpty(v)){if(b.length()>0)b.append("  •  ");b.append(v);} return b.length()==0?"Kontak belum diisi":b.toString(); }
    private LinearLayout card() { LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(15),dp(15),dp(15),dp(15)); l.setBackground(rounded(WHITE,18)); l.setElevation(dp(2)); return l; }
    private TextView text(String s,int size,int color,boolean bold) { TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setTypeface(bold?AppFont.semibold(this):AppFont.regular(this)); return t; }
    private Button button(String s,int color) { Button b=new Button(this); b.setText(s); b.setTextColor(WHITE); b.setTextSize(14); b.setAllCaps(false); b.setTypeface(AppFont.semibold(this)); b.setBackground(rounded(color,16)); return b; }
    private GradientDrawable rounded(int color,int radius) { GradientDrawable d=new GradientDrawable(); d.setColor(color); if(color==WHITE) d.setStroke(dp(1), BORDER); d.setCornerRadius(dp(radius)); return d; }
    private GradientDrawable gradient(int c1,int c2,int radius) { GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{c1,c2}); d.setCornerRadius(dp(radius)); return d; }
    private GradientDrawable outline() { GradientDrawable d=rounded(WHITE,13); d.setStroke(dp(1),BORDER); return d; }
    private int dp(float v) { return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
}
