package com.example.lokerku;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.FrameLayout;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import android.app.Dialog;
import android.view.Window;
import android.view.WindowManager;

import java.util.ArrayList;
import java.util.List;

public class InterviewTipsActivity extends AppCompatActivity {
    private final int BLUE=Color.rgb(0,82,255), DARK=Color.rgb(21,35,83), BG=Color.rgb(246,248,255), TEXT=Color.rgb(28,39,66), MUTED=Color.rgb(105,117,148), WHITE=Color.WHITE;
    private LinearLayout list;
    private String activeFilter="Semua";
    private final List<Tip> tips=new ArrayList<>();
    private static class Tip { String category,title,description,time,detail; Tip(String c,String t,String d,String tm,String de){category=c;title=t;description=d;time=tm;detail=de;} }

    @Override protected void onCreate(Bundle savedInstanceState) { super.onCreate(savedInstanceState); getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG); if(android.os.Build.VERSION.SDK_INT>=23)getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR); seed(); build(); }
    private void seed(){
        tips.add(new Tip("Persiapan","Riset perusahaan sebelum wawancara","Kenali produk, budaya kerja, dan kebutuhan posisi yang dilamar.","4 menit baca","Sebelum wawancara, buka situs resmi perusahaan dan pahami produk atau layanannya. Baca deskripsi pekerjaan lalu cocokkan kebutuhan posisi dengan pengalamanmu. Siapkan dua atau tiga pertanyaan yang relevan untuk perekrut. Hindari mengaku mengetahui hal yang belum kamu pahami."));
        tips.add(new Tip("Pertanyaan","Cara memperkenalkan diri dengan menarik","Buat jawaban singkat yang menyoroti pengalaman dan tujuanmu.","3 menit baca","Gunakan struktur sederhana: siapa kamu, pengalaman atau kemampuan yang relevan, lalu alasan tertarik pada posisi tersebut. Usahakan sekitar 45–90 detik. Hindari mengulang seluruh isi CV; pilih informasi yang paling sesuai dengan pekerjaan."));
        tips.add(new Tip("Pertanyaan","Menjawab pertanyaan kelebihan dan kekurangan","Sampaikan dengan jujur dan sertakan contoh nyata.","4 menit baca","Pilih kelebihan yang berhubungan dengan pekerjaan dan dukung dengan contoh. Untuk kekurangan, sebutkan hal nyata yang sedang kamu perbaiki beserta langkahnya. Hindari jawaban klise tanpa contoh atau mengklaim tidak memiliki kekurangan."));
        tips.add(new Tip("Saat wawancara","Gunakan metode STAR untuk cerita pengalaman","Susun jawaban menjadi Situasi, Tugas, Aksi, dan Hasil.","5 menit baca","Situasi: jelaskan konteksnya. Tugas: apa tanggung jawabmu. Aksi: langkah spesifik yang kamu ambil. Hasil: apa yang berubah atau kamu pelajari. Metode ini membantu jawaban tetap terstruktur, terutama untuk pertanyaan tentang kerja tim dan pemecahan masalah."));
        tips.add(new Tip("Setelah","Bahasa tubuh dan komunikasi profesional","Tunjukkan perhatian, dengarkan sampai selesai, dan jawab dengan jelas.","3 menit baca","Datang atau masuk ke ruang virtual tepat waktu. Dengarkan pertanyaan sampai selesai, berbicara dengan tempo wajar, dan minta klarifikasi jika pertanyaan belum jelas. Tetap sopan kepada semua orang yang ditemui, bukan hanya pewawancara."));
        tips.add(new Tip("Setelah","Apa yang dilakukan setelah wawancara","Kirim ucapan terima kasih singkat dan catat hal yang bisa diperbaiki.","2 menit baca","Setelah wawancara, kamu dapat mengirim pesan terima kasih yang ringkas jika kontak perekrut tersedia. Ulangi ketertarikan pada posisi dan apresiasi waktu mereka. Catat pertanyaan yang sulit agar kamu bisa berlatih untuk kesempatan berikutnya."));
    }
    private void build(){
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(BG); LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(20),dp(14),dp(20),dp(28)); scroll.addView(root); setContentView(scroll); FontEnforcer.apply(root,this);
        TextView back=text("‹   Kembali ke Beranda",14,BLUE,true); back.setPadding(0,dp(8),0,dp(18)); back.setOnClickListener(v->finish()); back.setMinHeight(dp(48));root.addView(back);
        LinearLayout hero=new LinearLayout(this); hero.setOrientation(LinearLayout.VERTICAL); hero.setPadding(dp(20),dp(22),dp(20),dp(22)); hero.setBackground(gradient(BLUE,Color.rgb(94,113,255),24));
        hero.addView(text("CAREER PLAYBOOK  ✦",11,Color.WHITE,true)); TextView title=text("Tampil percaya diri saat wawancara",24,WHITE,true); LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2);tp.topMargin=dp(10);hero.addView(title,tp);
        TextView desc=text("Bekali diri dengan strategi praktis, contoh jawaban, dan langkah yang bisa kamu lakukan sebelum sampai setelah wawancara.",13,Color.rgb(239,243,255),false);desc.setLineSpacing(dp(3),1f);LinearLayout.LayoutParams dp1=new LinearLayout.LayoutParams(-1,-2);dp1.topMargin=dp(8);hero.addView(desc,dp1);root.addView(hero);
        LinearLayout highlights=new LinearLayout(this);highlights.setOrientation(LinearLayout.HORIZONTAL);highlights.setGravity(Gravity.CENTER_VERTICAL);highlights.setPadding(dp(10),dp(15),dp(10),dp(15));highlights.setBackground(rounded(WHITE,18));String[][] stats={{"06","Panduan"},{"15 menit","Belajar"},{"04","Tahapan"}};for(int i=0;i<stats.length;i++){LinearLayout col=new LinearLayout(this);col.setOrientation(LinearLayout.VERTICAL);col.setGravity(Gravity.CENTER);col.setPadding(dp(4),dp(3),dp(4),dp(3));TextView number=text(stats[i][0],16,BLUE,true);number.setGravity(Gravity.CENTER);number.setSingleLine(false);col.addView(number,new LinearLayout.LayoutParams(-1,-2));TextView st=text(stats[i][1],10,MUTED,false);st.setGravity(Gravity.CENTER);st.setSingleLine(false);LinearLayout.LayoutParams stp=new LinearLayout.LayoutParams(-1,-2);stp.topMargin=dp(5);col.addView(st,stp);col.setMinimumHeight(dp(64));highlights.addView(col,new LinearLayout.LayoutParams(0,-2,1));if(i<stats.length-1){View divider=new View(this);divider.setBackgroundColor(Color.rgb(231,236,248));highlights.addView(divider,new LinearLayout.LayoutParams(dp(1),dp(34)));}}LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.topMargin=dp(15);root.addView(highlights,hp);
        TextView heading=text("Pilih topik yang kamu butuhkan",18,TEXT,true);LinearLayout.LayoutParams hdp=new LinearLayout.LayoutParams(-1,-2);hdp.topMargin=dp(24);root.addView(heading,hdp);TextView subtitle=text("Panduan singkat untuk setiap tahap wawancara.",12,MUTED,false);LinearLayout.LayoutParams sdp=new LinearLayout.LayoutParams(-1,-2);sdp.topMargin=dp(5);root.addView(subtitle,sdp);
        HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setHorizontalScrollBarEnabled(false);LinearLayout chips=new LinearLayout(this);chips.setOrientation(LinearLayout.HORIZONTAL);String[] filters={"Semua","Persiapan","Pertanyaan","Saat wawancara","Setelah"};for(String f:filters){TextView chip=text(f,12,f.equals(activeFilter)?WHITE:TEXT,true);chip.setGravity(Gravity.CENTER);chip.setPadding(dp(15),dp(10),dp(15),dp(10));chip.setBackground(rounded(f.equals(activeFilter)?BLUE:WHITE,30));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-2,-2);chip.setMinHeight(dp(48));cp.rightMargin=dp(8);chips.addView(chip,cp);chip.setOnClickListener(v->{activeFilter=f;updateChips(chips,filters);populate();showCategoryOverview(f);});}hsv.addView(chips);LinearLayout.LayoutParams hsvp=new LinearLayout.LayoutParams(-1,-2);hsvp.topMargin=dp(15);root.addView(hsv,hsvp);
        list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(8);root.addView(list,lp);populate();
        LinearLayout bottom=new LinearLayout(this);bottom.setOrientation(LinearLayout.VERTICAL);bottom.setPadding(dp(16),dp(17),dp(16),dp(17));bottom.setBackground(gradient(Color.rgb(232,240,255),Color.rgb(246,248,255),18));TextView bt=text("Latihan sedikit, lebih siap saat hari H",15,DARK,true);bottom.addView(bt);TextView bd=text("Pilih satu topik, baca dengan tenang, lalu coba jelaskan jawabanmu dengan kata-katamu sendiri.",12,MUTED,false);bd.setLineSpacing(dp(3),1f);LinearLayout.LayoutParams bdp=new LinearLayout.LayoutParams(-1,-2);bdp.topMargin=dp(6);bottom.addView(bd,bdp);LinearLayout.LayoutParams botp=new LinearLayout.LayoutParams(-1,-2);botp.topMargin=dp(18);root.addView(bottom,botp);
        FontEnforcer.apply(root,this); UiMotion.styleButtons(scroll); UiMotion.bindActions(scroll); UiMotion.bindPress(back);
        UiMotion.revealChildren(root,50,70,9);
    }
    @Override protected void onPause() {
        UiMotion.finishReveals(getWindow().getDecorView());
        super.onPause();
    }

    private void updateChips(LinearLayout chips,String[] filters){for(int i=0;i<chips.getChildCount();i++){TextView c=(TextView)chips.getChildAt(i);String f=filters[i];c.setBackground(rounded(f.equals(activeFilter)?BLUE:WHITE,30));c.setTextColor(f.equals(activeFilter)?WHITE:TEXT);}}
    private void populate(){list.removeAllViews();int count=0;for(Tip tip:tips){if(!activeFilter.equals("Semua")&&!tip.category.equalsIgnoreCase(activeFilter))continue;count++;LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.HORIZONTAL);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(13),dp(14),dp(13),dp(14));card.setBackground(rounded(WHITE,18));card.setElevation(dp(2));
        TextView icon=text(iconFor(tip.category),22,BLUE,true);icon.setGravity(Gravity.CENTER);icon.setBackground(rounded(tintFor(tip.category),14));card.addView(icon,new LinearLayout.LayoutParams(dp(52),dp(58)));
        LinearLayout words=new LinearLayout(this);words.setOrientation(LinearLayout.VERTICAL);words.setPadding(dp(12),0,dp(6),0);TextView category=text(tip.category.toUpperCase(),9,BLUE,true);words.addView(category);TextView title=text(tip.title,14,TEXT,true);title.setMaxLines(2);LinearLayout.LayoutParams t=new LinearLayout.LayoutParams(-1,-2);t.topMargin=dp(4);words.addView(title,t);TextView description=text(tip.description,11,MUTED,false);description.setMaxLines(2);description.setLineSpacing(dp(2),1f);LinearLayout.LayoutParams d=new LinearLayout.LayoutParams(-1,-2);d.topMargin=dp(5);words.addView(description,d);TextView time=text("◷  "+tip.time+"     Baca panduan  ›",10,BLUE,true);LinearLayout.LayoutParams tm=new LinearLayout.LayoutParams(-1,-2);tm.topMargin=dp(8);words.addView(time,tm);card.addView(words,new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams cardp=new LinearLayout.LayoutParams(-1,-2);cardp.topMargin=dp(10);list.addView(card,cardp);card.setOnClickListener(v->showDetail(tip));}
        if(count==0)list.addView(text("Belum ada panduan untuk kategori ini.",13,MUTED,false));
    }
    private void showCategoryOverview(String category){
        Dialog dialog=new Dialog(this);
        LinearLayout sheet=dialogSheet();
        addSheetHeader(dialog,sheet, category.equals("Semua")?"Semua panduan":"Panduan: "+category,
                category.equals("Semua")?"Pilih materi yang ingin kamu pelajari.":categoryDescription(category));
        LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(18),dp(4),dp(18),dp(10));
        int count=0;
        for(Tip tip:tips){
            if(!category.equals("Semua")&&!tip.category.equalsIgnoreCase(category))continue;
            count++;
            final Tip selected=tip;
            LinearLayout item=new LinearLayout(this);item.setOrientation(LinearLayout.HORIZONTAL);item.setGravity(Gravity.CENTER_VERTICAL);item.setPadding(dp(12),dp(12),dp(12),dp(12));item.setBackground(rounded(tintFor(tip.category),16));
            TextView num=text(String.format(java.util.Locale.getDefault(),"%02d",count),13,BLUE,true);num.setGravity(Gravity.CENTER);num.setBackground(rounded(WHITE,11));item.addView(num,new LinearLayout.LayoutParams(dp(38),dp(38)));
            LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setPadding(dp(11),0,dp(5),0);
            copy.addView(text(tip.title,13,TEXT,true));TextView meta=text(tip.time+"  ·  Buka panduan",11,MUTED,false);LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,-2);mp.topMargin=dp(4);copy.addView(meta,mp);item.addView(copy,new LinearLayout.LayoutParams(0,-2,1));TextView arrow=text("›",24,BLUE,true);item.addView(arrow);
            LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,-2);ip.topMargin=dp(8);content.addView(item,ip);item.setOnClickListener(v->{dialog.dismiss();showDetail(selected);});
        }
        if(count==0)content.addView(text("Belum ada panduan pada kategori ini.",13,MUTED,false));
        ScrollView scroller=new ScrollView(this);scroller.setFillViewport(false);scroller.addView(content);sheet.addView(scroller,new LinearLayout.LayoutParams(-1,0,1));
        Button done=primaryButton("Mulai membaca");LinearLayout.LayoutParams dp1=new LinearLayout.LayoutParams(-1,dp(50));dp1.setMargins(dp(18),dp(8),dp(18),dp(18));sheet.addView(done,dp1);done.setOnClickListener(v->{dialog.dismiss();for(Tip tip:tips){if(category.equals("Semua")||tip.category.equalsIgnoreCase(category)){showDetail(tip);break;}}});
        showDialog(dialog,sheet);
    }

    private void showDetail(Tip tip){
        Dialog dialog=new Dialog(this);
        LinearLayout sheet=dialogSheet();
        addSheetHeader(dialog,sheet,tip.category,"Panduan praktis untuk membantu kamu lebih siap.");
        LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(20),dp(4),dp(20),dp(12));
        TextView title=text(tip.title,22,DARK,true);title.setLineSpacing(dp(2),1f);content.addView(title);
        LinearLayout meta=new LinearLayout(this);meta.setOrientation(LinearLayout.HORIZONTAL);meta.setGravity(Gravity.CENTER_VERTICAL);meta.setPadding(dp(10),dp(7),dp(10),dp(7));meta.setBackground(rounded(Color.rgb(239,244,255),30));LinearLayout.LayoutParams metap=new LinearLayout.LayoutParams(-2,-2);metap.topMargin=dp(11);content.addView(meta,metap);meta.addView(text("◷  "+tip.time,11,BLUE,true));
        LinearLayout advice=new LinearLayout(this);advice.setOrientation(LinearLayout.VERTICAL);advice.setPadding(dp(15),dp(15),dp(15),dp(15));advice.setBackground(rounded(Color.rgb(246,248,255),16));TextView adviceTitle=text("Yang perlu kamu lakukan",13,DARK,true);advice.addView(adviceTitle);TextView body=text(tip.detail,14,TEXT,false);body.setLineSpacing(dp(6),1.08f);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.topMargin=dp(9);advice.addView(body,bp);LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,-2);ap.topMargin=dp(17);content.addView(advice,ap);
        TextView note=text("Tips LokerKu  ·  Pelajari, lalu sesuaikan dengan pengalamanmu sendiri.",11,MUTED,false);note.setLineSpacing(dp(3),1f);LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2);np.topMargin=dp(13);content.addView(note,np);
        ScrollView scroller=new ScrollView(this);scroller.setFillViewport(false);scroller.addView(content);sheet.addView(scroller,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);actions.setPadding(dp(18),dp(8),dp(18),dp(18));Button close=secondaryButton("Tutup");Button next=primaryButton("Topik berikutnya  ›");LinearLayout.LayoutParams cpar=new LinearLayout.LayoutParams(0,dp(48),0.85f);cpar.rightMargin=dp(9);actions.addView(close,cpar);actions.addView(next,new LinearLayout.LayoutParams(0,dp(48),1.3f));sheet.addView(actions);close.setOnClickListener(v->dialog.dismiss());next.setOnClickListener(v->{dialog.dismiss();int i=tips.indexOf(tip);showDetail(tips.get((i+1)%tips.size()));});
        showDialog(dialog,sheet);
    }

    private LinearLayout dialogSheet(){
        LinearLayout sheet=new LinearLayout(this);sheet.setOrientation(LinearLayout.VERTICAL);sheet.setBackground(rounded(WHITE,26));sheet.setClipToOutline(true);return sheet;
    }
    private void addSheetHeader(Dialog dialog,LinearLayout sheet,String titleText,String description){
        LinearLayout header=new LinearLayout(this);header.setOrientation(LinearLayout.VERTICAL);header.setPadding(dp(20),dp(20),dp(20),dp(18));header.setBackground(gradient(BLUE,Color.rgb(92,119,255),24));
        LinearLayout top=new LinearLayout(this);top.setOrientation(LinearLayout.HORIZONTAL);top.setGravity(Gravity.CENTER_VERTICAL);TextView eyebrow=text("LOKERKU  ✦  CAREER GUIDE",10,Color.rgb(230,238,255),true);top.addView(eyebrow,new LinearLayout.LayoutParams(0,-2,1));TextView close=text("×",27,WHITE,true);close.setGravity(Gravity.CENTER);top.addView(close,new LinearLayout.LayoutParams(dp(48),dp(48)));close.setContentDescription("Tutup");header.addView(top);close.setOnClickListener(v->dialog.dismiss());
        TextView title=text(titleText,22,WHITE,true);title.setLineSpacing(dp(2),1f);LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2);tp.topMargin=dp(11);header.addView(title,tp);TextView desc=text(description,12,Color.rgb(239,243,255),false);desc.setLineSpacing(dp(3),1f);LinearLayout.LayoutParams dp1=new LinearLayout.LayoutParams(-1,-2);dp1.topMargin=dp(6);header.addView(desc,dp1);sheet.addView(header);
    }
    private void showDialog(Dialog dialog,LinearLayout sheet){
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);dialog.setContentView(sheet);Window window=dialog.getWindow();if(window!=null){window.setBackgroundDrawableResource(android.R.color.transparent);window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);WindowManager.LayoutParams params=window.getAttributes();params.width=WindowManager.LayoutParams.MATCH_PARENT;params.height=(int)(getResources().getDisplayMetrics().heightPixels*0.82f);params.gravity=Gravity.BOTTOM;params.dimAmount=0.38f;window.setAttributes(params);}dialog.show();if(window!=null){window.setBackgroundDrawableResource(android.R.color.transparent);window.setLayout(WindowManager.LayoutParams.MATCH_PARENT,(int)(getResources().getDisplayMetrics().heightPixels*0.82f));window.setGravity(Gravity.BOTTOM);}FontEnforcer.apply(sheet,this);UiMotion.styleButtons(sheet);UiMotion.bindActions(sheet);UiMotion.revealChildren(sheet,40,70,5);
    }
    private Button primaryButton(String label){Button b=new Button(this);b.setText(label);b.setTextColor(WHITE);b.setTextSize(13);b.setAllCaps(false);b.setTypeface(AppFont.semibold(this));b.setBackground(rounded(BLUE,16));b.setElevation(dp(2));return b;}
    private Button secondaryButton(String label){Button b=new Button(this);b.setText(label);b.setTextColor(BLUE);b.setTextSize(13);b.setAllCaps(false);b.setTypeface(AppFont.semibold(this));GradientDrawable bg=rounded(Color.rgb(239,244,255),16);bg.setStroke(dp(1),Color.rgb(220,229,255));b.setBackground(bg);return b;}
    private String categoryDescription(String category){if(category.equals("Persiapan"))return "Hal-hal yang bisa kamu siapkan sebelum hari wawancara.";if(category.equals("Pertanyaan"))return "Latihan menjawab pertanyaan yang sering muncul dari perekrut.";if(category.equals("Saat wawancara"))return "Cara menyampaikan pengalaman dan berkomunikasi dengan percaya diri.";if(category.equals("Setelah"))return "Langkah profesional setelah sesi wawancara selesai.";return "Pilih panduan yang sesuai dengan kebutuhanmu.";}
    private String iconFor(String c){if(c.equals("Persiapan"))return "◎";if(c.equals("Pertanyaan"))return "❝";if(c.equals("Saat wawancara"))return "✦";return "✓";}
    private int tintFor(String c){if(c.equals("Persiapan"))return Color.rgb(228,235,255);if(c.equals("Pertanyaan"))return Color.rgb(233,233,255);if(c.equals("Saat wawancara"))return Color.rgb(225,234,255);return Color.rgb(235,239,255);}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setTypeface(bold?AppFont.semibold(this):AppFont.regular(this));return t;}
    private GradientDrawable rounded(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);if(color==WHITE)d.setStroke(dp(1),Color.rgb(221,224,255));d.setCornerRadius(dp(radius));return d;}
    private GradientDrawable gradient(int c1,int c2,int radius){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{c1,c2});d.setCornerRadius(dp(radius));return d;}
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
}
