package com.example.lokerku;

import android.content.Context;
import android.graphics.Typeface;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public final class FontEnforcer {

    private FontEnforcer() { }

    public static void apply(View view, Context context) {
        if (view instanceof TextView) {
            TextView textView = (TextView) view;
            Typeface current = textView.getTypeface();

            // Apply bundled Poppins even when the device replaces system fonts.
            Typeface regular = AppFont.regular(context);
            Typeface semibold = AppFont.semibold(context);
            boolean bold = current != null && (current.equals(semibold) || current.isBold());
            textView.setTypeface(bold ? semibold : regular);
        }

        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                apply(group.getChildAt(i), context);
            }
        }
    }
}
