package com.example.lokerku;

import android.animation.ValueAnimator;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.animation.LinearInterpolator;

public final class AnimatedGradientBackground {

    private AnimatedGradientBackground() {
    }

    public static void apply(View view) {
        final int[][] palettes = {
                {
                        Color.rgb(13, 24, 55),
                        Color.rgb(36, 76, 170),
                        Color.rgb(23, 145, 160)
                },
                {
                        Color.rgb(35, 24, 85),
                        Color.rgb(77, 64, 190),
                        Color.rgb(28, 128, 155)
                },
                {
                        Color.rgb(10, 47, 75),
                        Color.rgb(20, 111, 155),
                        Color.rgb(48, 76, 170)
                }
        };

        final GradientDrawable gradient = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                palettes[0]
        );

        view.setBackground(gradient);

        ValueAnimator animator = ValueAnimator.ofFloat(0f, 3f);
        animator.setDuration(18000);
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setInterpolator(new LinearInterpolator());

        animator.addUpdateListener(animation -> {
            float position = (float) animation.getAnimatedValue();

            int current = Math.min((int) position, palettes.length - 1);
            int next = (current + 1) % palettes.length;
            float fraction = position - current;

            int[] colors = new int[3];

            for (int i = 0; i < colors.length; i++) {
                colors[i] = blend(
                        palettes[current][i],
                        palettes[next][i],
                        fraction
                );
            }

            gradient.setColors(colors);
        });

        animator.start();

        view.setTag(R.id.animated_gradient_animator, animator);
    }

    private static int blend(int from, int to, float fraction) {
        return Color.rgb(
                (int) (Color.red(from) +
                        (Color.red(to) - Color.red(from)) * fraction),
                (int) (Color.green(from) +
                        (Color.green(to) - Color.green(from)) * fraction),
                (int) (Color.blue(from) +
                        (Color.blue(to) - Color.blue(from)) * fraction)
        );
    }
}
