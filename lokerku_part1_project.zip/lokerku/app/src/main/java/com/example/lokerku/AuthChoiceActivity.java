package com.example.lokerku;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

/** Entry choice; existing login and registration flows remain unchanged. */
public class AuthChoiceActivity extends AppCompatActivity {
    private int dp(float n){return (int)(getResources().getDisplayMetrics().density*n+.5f);}
    private TextView label(String value,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);
        t.setTypeface(bold?AppFont.semibold(this):AppFont.regular(this));t.setGravity(Gravity.CENTER);return t;
    }
    private Button action(String title,boolean primary){
        Button b=new Button(this);b.setText(title);b.setAllCaps(false);b.setTextSize(15);
        b.setTextColor(Color.WHITE);b.setTypeface(AppFont.semibold(this));b.setMinHeight(dp(52));
        b.setPadding(dp(16),dp(10),dp(16),dp(10));b.setSingleLine(false);b.setLetterSpacing(0f);
        GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            primary?new int[]{0xff2b4df2,0xff335bf5}:new int[]{0x4dffffff,0x25202070});
        bg.setCornerRadius(dp(16));bg.setStroke(dp(1),primary?0xff8daaff:0x99c9ddff);
        b.setBackgroundTintList(null);b.setBackground(bg);b.setStateListAnimator(null);return b;
    }
    @Override protected void onCreate(Bundle state){super.onCreate(state);
        getWindow().setStatusBarColor(0xff091b58);getWindow().setNavigationBarColor(0xff172e78);
        getWindow().getDecorView().setSystemUiVisibility(0);
        FrameLayout frame=new FrameLayout(this);frame.addView(new AuthAmbientView(this),new FrameLayout.LayoutParams(-1,-1));
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(Color.TRANSPARENT);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setGravity(Gravity.CENTER);
        root.setPadding(dp(22),dp(36),dp(22),dp(36));scroll.addView(root);frame.addView(scroll);
        TextView brand=label("✦  LOKERKU",13,0xffdfebff,true);brand.setLetterSpacing(.10f);
        LinearLayout.LayoutParams brandp=new LinearLayout.LayoutParams(-1,-2);brandp.bottomMargin=dp(20);root.addView(brand,brandp);
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(22),dp(28),dp(22),dp(24));
        card.setBackground(AuthGlass.card(this));root.addView(card,new LinearLayout.LayoutParams(-1,-2));
        TextView title=label("Peluang baru,\nlangkah baru.",26,Color.WHITE,true);title.setLineSpacing(dp(2),1f);card.addView(title);
        TextView description=label("Temukan pekerjaan dan kelola perjalanan kariermu bersama LokerKu.",13,0xffe1ebff,false);
        description.setLineSpacing(dp(3),1f);LinearLayout.LayoutParams d=new LinearLayout.LayoutParams(-1,-2);d.topMargin=dp(12);d.bottomMargin=dp(26);card.addView(description,d);
        Button login=action("Masuk",true);card.addView(login,new LinearLayout.LayoutParams(-1,-2));
        Button register=action("Daftar",false);LinearLayout.LayoutParams r=new LinearLayout.LayoutParams(-1,-2);r.topMargin=dp(12);card.addView(register,r);
        TextView hint=label("Pilih cara untuk melanjutkan",11,0xffdce8ff,false);LinearLayout.LayoutParams h=new LinearLayout.LayoutParams(-1,-2);h.topMargin=dp(18);card.addView(hint,h);
        login.setOnClickListener(v->startActivity(new Intent(this,LoginActivity.class)));
        register.setOnClickListener(v->startActivity(new Intent(this,RegisterActivity.class)));
        setContentView(frame);FontEnforcer.apply(frame,this);UiMotion.bindPress(login);UiMotion.bindPress(register);UiMotion.reveal(card,100);
    }
    @Override protected void onPause(){UiMotion.finishReveals(getWindow().getDecorView());super.onPause();}
}
