package com.example.lokerku;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;

public class AccountCenterActivity extends AppCompatActivity {
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setTypeface(bold?AppFont.semibold(this):AppFont.regular(this));return t;}
    private GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    @Override protected void onCreate(Bundle state){super.onCreate(state);
        ScrollView scroll=new ScrollView(this); scroll.setBackgroundColor(0xfff7f8ff);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(20),dp(26),dp(20),dp(30));scroll.addView(root);
        TextView back=text("‹  Kembali",15,0xff0000cc,true);back.setPadding(0,0,0,dp(24));back.setOnClickListener(v->finish());root.addView(back);
        TextView label=text("LOKERKU  /  PUSAT AKUN",10,0xff0000cc,true);label.setLetterSpacing(.08f);root.addView(label);
        TextView title=text("Kelola akunmu",26,0xff1b273d,true);root.addView(title);
        TextView desc=text("Perbarui profil dan kendalikan keamanan akun dalam satu tempat.",13,0xff68708f,false);desc.setPadding(0,dp(8),0,dp(22));root.addView(desc);
        item(root,"Profil dan detail pribadi","Perbarui informasi profil",()->startActivity(new Intent(this,ProfileActivity.class)));
        item(root,"Kata sandi & keamanan","Buat atau ubah kata sandi",this::changePassword);
        item(root,"Nonaktifkan akun","Sembunyikan profil sampai kamu masuk kembali",()->confirmAction("deactivate"));
        item(root,"Hapus akun permanen","Hapus akun, sertifikat, dan riwayat lamaran",()->confirmAction("delete"));
        setContentView(scroll);FontEnforcer.apply(root,this);UiMotion.bindActions(root);UiMotion.revealChildren(root,100,65,6);
    }
    private void item(LinearLayout root,String title,String sub,Runnable click){
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(18),dp(16),dp(18),dp(16));card.setBackground(bg(Color.WHITE,20));card.setElevation(dp(2));
        card.addView(text(title+"   ›",15,0xff1b273d,true));TextView detail=text(sub,12,0xff68708f,false);detail.setPadding(0,dp(5),0,0);card.addView(detail);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(10);root.addView(card,p);card.setOnClickListener(v->click.run());
    }
    private EditText passwordInput(String hint){EditText e=new EditText(this);e.setHint(hint);e.setSingleLine(true);e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);e.setTypeface(AppFont.regular(this));return e;}
    private void changePassword(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(20),0,dp(20),0);
        EditText pass=passwordInput("Kata sandi baru");EditText confirm=passwordInput("Ulangi kata sandi");box.addView(pass); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=dp(10);box.addView(confirm,cp);
        new PremiumDialog.Builder(this).setTitle("Kata sandi baru").setMessage("Kata sandi untuk LokerKu, bukan akun Google. Gunakan 8–72 karakter.").setView(box).setNegativeButton("Batal",null).setPositiveButton("Lanjutkan",(d,w)->{
            String n=pass.getText().toString();if(n.length()<8||n.length()>72||!n.equals(confirm.getText().toString())){toast("Pastikan password sama dan 8–72 karakter.");return;}
            verifyAndRun("change_password",n);
        }).show();
    }
    private void confirmAction(String action){
        boolean delete="delete".equals(action);
        new PremiumDialog.Builder(this).setTitle(delete?"Hapus akun permanen?":"Nonaktifkan akun?")
            .setMessage(delete?"Akun, sertifikat, foto, dan riwayat lamaran akan dihapus permanen. Tindakan ini tidak dapat dibatalkan.":"Profil dan sertifikat publik akan disembunyikan. Masuk kembali untuk mengaktifkan akun.")
            .setNegativeButton("Batal",null).setPositiveButton(delete?"Hapus akun":"Nonaktifkan",(d,w)->verifyAndRun(action,null)).show();
    }
    private void verifyAndRun(String action,String newPassword){
        new PremiumDialog.Builder(this).setTitle("Verifikasi pemilik akun").setItems(new String[]{"Gunakan password LokerKu","Gunakan akun Google"},(d,which)->{
            if(which==0){EditText field=passwordInput("Password LokerKu saat ini");
                new PremiumDialog.Builder(this).setTitle("Masukkan password").setView(field).setNegativeButton("Batal",null).setPositiveButton("Verifikasi",(x,w)->{
                    Map<String,String> p=new HashMap<>();p.put("password",field.getText().toString());send(action,newPassword,p);
                }).show();
            } else GoogleSignInFlow.fresh(this,new GoogleSignInFlow.FreshCredential(){
                public void fail(String message){toast(message);} public void ready(String token,String nonce){Map<String,String> p=new HashMap<>();p.put("id_token",token);p.put("nonce",nonce);send(action,newPassword,p);}
            });
        }).setNegativeButton("Batal",null).show();
    }
    private void send(String action,String newPassword,Map<String,String> data){
        data.put("action",action);if(newPassword!=null)data.put("new_password",newPassword);
        ApiClient.post(this,"auth/account.php",data,new ApiClient.Result(){
            public void success(JSONObject json){toast(json.optString("message","Berhasil"));SessionStore.clear(AccountCenterActivity.this);
                if("delete".equals(action)) {
                    getSharedPreferences(FavoritesStore.name(AccountCenterActivity.this),MODE_PRIVATE).edit().clear().apply();
                    getSharedPreferences("lokerku_notes_" + getSharedPreferences("lokerku_user",MODE_PRIVATE).getInt("id",0),MODE_PRIVATE).edit().clear().apply();
                }
                getSharedPreferences("lokerku_user",MODE_PRIVATE).edit().clear().apply();
                Intent i=new Intent(AccountCenterActivity.this,LoginActivity.class);i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);startActivity(i);finish();}
            public void fail(String message){toast(message);}
        });
    }
    private void toast(String m){Toast.makeText(this,m,Toast.LENGTH_LONG).show();}
}
