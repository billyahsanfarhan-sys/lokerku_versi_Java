package com.example.lokerku;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;
import android.view.animation.LinearInterpolator;

/** Scattered letters assemble in deliberate steps; no flashing effects. */
public class LokerKuSplashView extends View {
    public interface AnimationListener { void onAnimationFinished(); }
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.SUBPIXEL_TEXT_FLAG);
    private final Typeface regular,semibold;
    private ValueAnimator animator; private AnimationListener listener;
    private Shader background; private float progress; private boolean started,finished;
    private final float[] xs={.13f,.75f,.29f,.85f,.14f,.72f,.50f};
    private final float[] ys={.22f,.17f,.62f,.59f,.45f,.73f,.10f};
    public LokerKuSplashView(Context c){super(c);regular=AppFont.regular(c);semibold=AppFont.semibold(c);setContentDescription("LokerKu, temukan peluang kariermu");}
    public void setAnimationListener(AnimationListener l){listener=l;}
    private float dp(float n){return n*getResources().getDisplayMetrics().density;}
    private float sp(float n){return n*getResources().getDisplayMetrics().scaledDensity;}
    private float ramp(float start,float duration){return Math.max(0,Math.min(1,(progress-start)/duration));}
    @Override protected void onSizeChanged(int w,int h,int ow,int oh){super.onSizeChanged(w,h,ow,oh);if(w<=0||h<=0)return;
        background=new LinearGradient(0,0,w,h,new int[]{0xff081844,0xff172f82,0xff333ca1},null,Shader.TileMode.CLAMP);
        if(started)return;started=true;animator=ValueAnimator.ofFloat(0,1);animator.setDuration(7200);animator.setInterpolator(new LinearInterpolator());
        animator.addUpdateListener(a->{progress=(Float)a.getAnimatedValue();invalidate();});
        animator.addListener(new AnimatorListenerAdapter(){private boolean cancelled;
            @Override public void onAnimationCancel(Animator a){cancelled=true;}
            @Override public void onAnimationEnd(Animator a){if(!cancelled&&!finished){finished=true;if(listener!=null)listener.onAnimationFinished();}}});animator.start();
    }
    private void glow(Canvas c,float x,float y,float r,int color){paint.setShader(new RadialGradient(x,y,r,new int[]{color,0x00000000},null,Shader.TileMode.CLAMP));paint.setStyle(Paint.Style.FILL);c.drawCircle(x,y,r,paint);paint.setShader(null);}
    @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();if(w<=0||h<=0)return;
        float cx=w/2,cy=h*.46f;paint.setShader(background);paint.setStyle(Paint.Style.FILL);c.drawPaint(paint);paint.setShader(null);
        glow(c,w*.8f+dp(15)*(float)Math.sin(progress*6.28f),h*.22f,w*.68f,0x8b75aaff);
        glow(c,w*.17f,h*.72f,w*.58f,0x75499fff);glow(c,cx,cy,w*.48f,0x4c9cc9ff);
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(1));
        for(int i=0;i<5;i++){paint.setColor(Color.argb(35+i*6,196,218,255));Path path=new Path();float wave=dp(8)*(float)Math.sin(progress*6.28f+i);
            path.moveTo(-w*.2f,h*(.22f+.11f*i)+wave);path.cubicTo(w*.25f,h*(.10f+.10f*i),w*.7f,h*(.37f+.08f*i),w*1.2f,h*(.2f+.10f*i)-wave);c.drawPath(path,paint);}
        paint.setStyle(Paint.Style.FILL);for(int i=0;i<28;i++){float x=w*(.04f+.91f*((i*37%101)/100f));float y=h*(.07f+.82f*((i*61%103)/102f))+dp(6)*(float)Math.sin(progress*6.28f+i);
            paint.setColor(Color.argb(75+(i%4)*22,218,234,255));c.drawCircle(x,y,dp(i%7==0?2:1),paint);}
        String word="LokerKu";text.setTypeface(semibold);text.setTextSize(Math.min(sp(41),w*.105f));text.setTextAlign(Paint.Align.LEFT);
        float width=text.measureText(word), target=cx-width/2;float baseline=cy-(text.ascent()+text.descent())/2;
        for(int i=0;i<word.length();i++){
            String letter=word.substring(i,i+1);float size=text.measureText(letter);float tx=target+size/2;
            float t=ramp(.16f+i*.025f,.62f);float stepped=t>=1f?1f:(float)Math.floor(t*6)/6f;
            float x=xs[i]*w+(tx-xs[i]*w)*stepped, y=ys[i]*h+(baseline-ys[i]*h)*stepped;
            c.save();c.translate(x,y);c.rotate((i%2==0?-20:20)*(1-stepped));
            text.setColor(Color.argb((int)(255*ramp(.01f+i*.012f,.10f)),245,249,255));c.drawText(letter,-size/2,0,text);c.restore();target+=size;
        }
        float sub=ramp(.82f,.12f);text.setTextAlign(Paint.Align.CENTER);text.setTypeface(regular);text.setTextSize(Math.min(sp(13),w*.034f));text.setColor(Color.argb((int)(235*sub),220,235,255));
        c.drawText("Temukan peluang kariermu",cx,cy+dp(48),text);
        float lineY=h*.84f,lineW=Math.min(dp(130),w*.32f);paint.setColor(0x50d9eaff);c.drawRoundRect(cx-lineW/2,lineY,cx+lineW/2,lineY+dp(3),dp(2),dp(2),paint);
        float fill=Math.min(1f,progress/.94f);paint.setColor(0xffe6f3ff);if(fill>0f)c.drawRoundRect(cx-lineW/2,lineY,cx-lineW/2+lineW*fill,lineY+dp(3),dp(2),dp(2),paint);
        text.setTypeface(semibold);text.setTextSize(Math.min(sp(9),w*.025f));text.setColor(0xbddce9ff);c.drawText("MEMULAI LOKERKU",cx,h*.90f,text);
    }
    public void pauseAnimations(){if(animator!=null&&animator.isRunning())animator.pause();}
    public void resumeAnimations(){if(animator!=null&&animator.isPaused())animator.resume();}
    public void stopAnimations(){if(animator!=null){animator.cancel();animator=null;}}
}
