package com.example.lokerku;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;

/** Translucent layered surface. Not a real-time background blur. */
final class AuthGlass {
    private AuthGlass() { }
    static GradientDrawable card(Context c) {
        float d=c.getResources().getDisplayMetrics().density;
        GradientDrawable glass=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0x9c213675,0xac182a61,0xb4122050});
        glass.setCornerRadius(28*d);glass.setStroke(Math.max(1,Math.round(d)),0x99e6f3ff);return glass;
    }
    static GradientDrawable field(Context c, boolean focused) {
        float d=c.getResources().getDisplayMetrics().density;
        GradientDrawable glass=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x54243260,0x78202d56});
        glass.setCornerRadius(14*d);glass.setStroke(Math.max(1,Math.round((focused?2:1)*d)),focused?0xffd4eeff:0x99c6dcff);return glass;
    }
}
