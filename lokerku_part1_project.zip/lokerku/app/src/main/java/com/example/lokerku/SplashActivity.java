package com.example.lokerku;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {

    private LokerKuSplashView splashView;
    private boolean sudahPindah = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();

        window.setStatusBarColor(Color.rgb(10, 35, 78));
        window.setNavigationBarColor(Color.rgb(10, 35, 78));

        window.getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
        );

        splashView = new LokerKuSplashView(this);

        splashView.setAnimationListener(() -> {
            if (isFinishing() || sudahPindah) {
                return;
            }

            sudahPindah = true;

            Intent intent = new Intent(
                    SplashActivity.this,
                    AuthChoiceActivity.class
            );

            startActivity(intent);

            overridePendingTransition(
                    R.anim.screen_enter,
                    R.anim.screen_exit
            );

            finish();
        });

        setContentView(splashView);
    }

    @Override
    protected void onPause() {
        if (splashView != null) splashView.pauseAnimations();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (splashView != null) splashView.resumeAnimations();
    }

    @Override
    protected void onDestroy() {
        if (splashView != null) {
            splashView.stopAnimations();
        }

        super.onDestroy();
    }
}
