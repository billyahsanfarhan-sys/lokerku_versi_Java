package com.example.lokerku;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.CancellationSignal;
import android.widget.Toast;
import androidx.core.content.ContextCompat;
import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.GetCredentialException;
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;

final class GoogleSignInFlow {
    private static final String BASE="https://ahannaja.cu.ma/lokerku_api/";
    private static final String CLIENT="579438749291-sdlee32ci5m8e1rjf0506o3b2gj2asus.apps.googleusercontent.com";
    interface FreshCredential { void ready(String token,String nonce); void fail(String message); }
    static void fresh(Activity activity, FreshCredential callback) {
        StringRequest req=new StringRequest(Request.Method.POST,BASE+"auth/google_nonce.php",response -> {
            try {
                JSONObject json=new JSONObject(response); String nonce=json.optString("nonce","");
                if(!json.optBoolean("success") || !nonce.matches("[a-f0-9]{64}")) {callback.fail("Server belum siap untuk Google."); return;}
                GetSignInWithGoogleOption option=new GetSignInWithGoogleOption.Builder(CLIENT).setNonce(nonce).build();
                GetCredentialRequest request=new GetCredentialRequest.Builder().addCredentialOption(option).build();
                CredentialManager.create(activity).getCredentialAsync(activity,request,new CancellationSignal(),
                    ContextCompat.getMainExecutor(activity),new CredentialManagerCallback<GetCredentialResponse,GetCredentialException>() {
                        @Override public void onResult(GetCredentialResponse result) {
                            try {
                                Credential credential=result.getCredential();
                                if(!(credential instanceof CustomCredential) || !GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(credential.getType())) {
                                    callback.fail("Kredensial Google tidak dikenali."); return;
                                }
                                String token=GoogleIdTokenCredential.createFrom(credential.getData()).getIdToken();
                                callback.ready(token,nonce);
                            } catch(Exception e) {callback.fail("Tidak dapat membaca akun Google.");}
                        }
                        @Override public void onError(GetCredentialException e) { callback.fail("Google belum dapat dibuka (" + e.getClass().getSimpleName() + "). Periksa akun Google dan Play Services."); }
                    });
            } catch(Exception e){callback.fail("Respons server tidak valid.");}
        },error -> callback.fail("Tidak dapat menghubungi server untuk Google."));
        req.setRetryPolicy(new DefaultRetryPolicy(15000,0,1)); Volley.newRequestQueue(activity.getApplicationContext()).add(req);
    }
    static void signIn(Activity activity, boolean register, Runnable onFinished) {
        fresh(activity,new FreshCredential() {
            @Override public void fail(String m) {onFinished.run(); Toast.makeText(activity,m,Toast.LENGTH_LONG).show();}
            @Override public void ready(String idToken,String nonce) {
                StringRequest req=new StringRequest(Request.Method.POST,BASE+"auth/google.php",response -> {
                    try { JSONObject json=new JSONObject(response);
                        if(!json.optBoolean("success")) {fail(json.optString("message","Gagal masuk Google.")); return;}
                        JSONObject user=json.getJSONObject("user"); String token=json.getString("session_token");
                        saveUser(activity,user,token);
                        Intent intent=new Intent(activity,MainActivity.class); intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        activity.startActivity(intent); activity.finish();
                    } catch(Exception e) {fail("Tidak dapat menyimpan sesi. Silakan coba lagi.");}
                },error -> {
                    String msg="Tidak dapat menghubungi server.";
                    if(error.networkResponse!=null && error.networkResponse.data!=null) try {
                        msg=new JSONObject(new String(error.networkResponse.data,java.nio.charset.StandardCharsets.UTF_8)).optString("message",msg);
                    } catch(Exception ignored){}
                    fail(msg);
                }) { @Override protected Map<String,String> getParams(){ Map<String,String> p=new HashMap<>();
                    p.put("mode",register?"register":"login");p.put("id_token",idToken);p.put("nonce",nonce);return p; } };
                req.setRetryPolicy(new DefaultRetryPolicy(20000,0,1)); Volley.newRequestQueue(activity.getApplicationContext()).add(req);
            }
        });
    }
    static void saveUser(Activity activity,JSONObject user,String token) throws Exception {
        if(user.optInt("id",0)<=0 || !token.matches("[a-f0-9]{64}")) throw new Exception("invalid session");
        SessionStore.save(activity,token);
        SharedPreferences p=activity.getSharedPreferences("lokerku_user",Activity.MODE_PRIVATE);
        FavoritesStore.migrate(activity, p.getInt("id",0), user.getInt("id"));
        p.edit().clear().putInt("id",user.getInt("id"))
            .putString("nama",value(user,"nama")).putString("username",value(user,"username"))
            .putString("email",value(user,"email")).putString("phone",value(user,"no_hp"))
            .putString("foto",value(user,"foto")).putString("role",value(user,"role"))
            .putString("profile_headline",value(user,"profile_headline")).putString("profile_lokasi",value(user,"profile_lokasi"))
            .putString("profile_bio",value(user,"profile_bio")).putString("profile_linkedin",value(user,"profile_linkedin"))
            .putString("profile_portfolio",value(user,"profile_portfolio")).apply();
    }
    private static String value(JSONObject j,String key){ return j.isNull(key)?"":j.optString(key,""); }
}
